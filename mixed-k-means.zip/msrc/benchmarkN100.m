nTrials = 100
-------------------------
Iris
Elapsed time is 4277.812547 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance    0.85416         0.84174       
    Silhouette     0.79697         0.81175       

-------------------------
Lenses
Elapsed time is 254.807561 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance    0.51391         0.48783       
    Silhouette     0.59164         0.58876       

-------------------------
Heart
Elapsed time is 8931.101548 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance    0.83981         0.75615       
    Silhouette     0.45644         0.79679       

-------------------------
Vote
Elapsed time is 7893.835162 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance    0.87327         0.85276       
    Silhouette     0.75569         0.61025       

-------------------------
Australian
Elapsed time is 7232.194358 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance    0.75392         0.59216       
    Silhouette     0.59283         0.86832       

-------------------------
