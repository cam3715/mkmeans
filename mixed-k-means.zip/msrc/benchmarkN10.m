nTrials = 10
-------------------------
Iris
Elapsed time is 480.705623 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance    0.88591         0.82282       
    Silhouette     0.78531         0.81208       

-------------------------
Lenses
Elapsed time is 26.449903 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance    0.58261         0.46522       
    Silhouette     0.58863         0.58624       

-------------------------
Heart
Elapsed time is 838.774515 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance    0.83963         0.76296       
    Silhouette     0.45377         0.81353       

-------------------------
Vote
Elapsed time is 670.403463 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance    0.87327         0.86866       
    Silhouette     0.75569         0.61724       

-------------------------
Australian
Elapsed time is 164.631749 seconds.
-------------------------
                   Mixed_kMeans    Numeric_kMeans
                   ____________    ______________

    Performance      0.782         0.61248       
    Silhouette     0.58958         0.89507       

-------------------------