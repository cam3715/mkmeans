function result = kmeansCompare_fs(filename, catAttributes, ncols, startRow, trialsNo, turnoffFigures)
%KEMANSCOMPARE_FS interface for csv file with known output
%   csv file must be in MATLAB directory, in numeric matrix form
%   computes IDX for numeric and mixed kmeans clustering.
%   plots silhouette values and performance ratios for each.
%
% Inputs:
%     filename         - string of file name
%     catAttributes    - vector of categorical attribute col numbers
%     ncols            - number of columns in the csv file
%     startRow         - row to start data input (default = 1)
% Outputs:
%     result                 - output struct
%         .mixedClustering   - struct with results from mixed method
%             .k             - number of means
%             .idx           - cluster assignments (indicies) for each trial
%             .silhouette    - mean silhouette values for each trial
%             .perfCompare   - mean performance for each trial
%             .distances     - distance from each point to each center
%             .trialsNo      - number of trials
%         .numericClustering - struct with results from numeric method
%             .k             - number of means
%             .idx           - cluster assignments (indicies) for each trial
%             .silhouette    - mean silhouette values for each trial
%             .perfCompare   - mean performance for each trial
%             .distances     - distance from each point to each center
%             .trialsNo      - number of trials
%         .originalData      - struct with original input and idx data
%             .data          - numeric matrix of data
%             .output        - given idx for known values
%
% Other m-files required:
%     assignmentoptimal.m, Markus Buehren ...
%         http://www.mathworks.com/matlabcentral/fileexchange/ ...
%         6543-functions-for-the-rectangular-assignment-problem ...
%         /content/assignmentoptimal.m
%     kmeansCompare.m, Camden Bock
%
%
% Author: Camden Glenn Bock
% 598 Bates College, Lewistion, ME 04240
% cbock@bates.edu, camdenbock@gmail.com
% http://www.camdenbock.com
% December 2015; Last Revision: 12/30/2015
%
%% Copyright (C) 2016  Camden Bock - GPL v. 3.0
%
% 'This program is liscensed under GPL v3.0'
% 'This program is modified from Ahmad Alsahaf`s package: ...
% amjams/mixedkmeans'.
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
%
% 'This program comes with ABSOLUTELY NO WARRANTY;' ...
% 'for details type view source. This is free software, and' ...
% 'you are welcome to redistribute it display under certain' ...
% 'conditions; see <http://www.gnu.org/licenses/>', ...
% ('Copyright (C) 2016  Camden Bock, Bates College'))



%------------- BEGIN CODE --------------
%% Initialize variables.
close all
if nargin < 6
    turnoffFigures = 0;
elseif nargin < 5
    trialsNo = 5;
elseif nargin < 4
    startRow = 1;
elseif nargin < 3
    display('not enough inputs')
end

delimiter = ',';
endRow = inf;

%% Format string for each line of text:  Autmoated for user input
inputBlock = ('%f');
formatSpec = char(1:(2*ncols + 8));
for i = 2:2:(2*ncols)
    formatSpec((i-1):i) = inputBlock;
end
formatSpec((2*ncols+1):(2*ncols+8))=('%[^\n\r]');

%% Open the text file.
fileID = fopen(filename,'r');

%% Read columns of data according to format string.
% This call is based on the structure of the file used to generate this
% code. If an error occurs for a different file, try regenerating the code
% from the Import Tool.
dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1, ...
    'Delimiter', delimiter, 'HeaderLines', startRow(1)-1, ... 
    'ReturnOnError', false);
for block=2:length(startRow)
    frewind(fileID);
    dataArrayBlock = textscan(fileID, formatSpec, ... 
        endRow(block)-startRow(block)+1, 'Delimiter', delimiter, ...
        'HeaderLines', startRow(block)-1, 'ReturnOnError', false);
    for col=1:length(dataArray)
        dataArray{col} = [dataArray{col};dataArrayBlock{col}];
    end
end

%% Close the text file.
fclose(fileID);

%% Create output variable
datasource = [dataArray{1:end-1}];

%% Options for alsahaf_mixed_kmeans
data = datasource(:,1:(end-1));
output = datasource(:,end);
if min(min(output))==0
    output = output + 1;
elseif min(min(output))~=1
    disp('Error: Datasource may not have proper categorical assignments')
end
max_iter = 1000;

k = length(unique(output));

[~,dc] = size(data);
inputType = zeros(1,dc);
for q=1:length(catAttributes)
    inputType(catAttributes(q)) = 1;
    if min(min(data(:,catAttributes(q))))== 0
        data(:,catAttributes(q)) = data(:,catAttributes(q)) + 1;
    elseif min(min(data(:,catAttributes(q))))~=1
        disp('Error: Datasource may not have proper categorical assignments')
    end
end

[mixedClustering,numericClustering, origionalData] = ... 
    kmeansCompare(data, k, max_iter, inputType, output, trialsNo, turnoffFigures);

%output variable
result = struct;
result.mixedClustering = mixedClustering;
result.numericClustering = numericClustering;
result.origionalData = origionalData;
end