function  [mixedClustering,numericClustering, origionalData] = kmeansCompare(data, k, max_iter, inputType, output, trialsNo,turnoffFigures)
%KMEANSCOMPARE computes IDX for numeric and mixed kmeans clustering.
%   plots silhouette values and performance ratios for each.
%
% Inputs:
%     data               - mxn matrix of n data points wiht m attributes
%     k                  - number of means (cluster centers)
%     max_iter           - maximum iterations for k-means
%     inputType          - binary: attribute is (1= categorical 0= numeric)
%     output             - given indicies for clusters in known structure
%     trialsNo           - maximum number of means for clustering in the
%                             discretation of numeric data
%
% Outputs:
%     mixedClustering    - struct with results from mixed method
%         .k             - number of means
%         .idx           - cluster assignments (indicies) for each trial
%         .silhouette    - mean silhouette values for each trial
%         .perfCompare   - mean performance for each trial
%         .distances     - distance from each point to each center
%         .trialsNo      - number of trials
%     numericClustering  - struct with results from numeric method
%         .k             - number of means
%         .idx           - cluster assignments (indicies) for each trial
%         .silhouette    - mean silhouette values for each trial
%         .perfCompare   - mean performance for each trial
%         .distances     - distance from each point to each center
%         .trialsNo      - number of trials
%     originalData       - struct with original input and idx data
%         .data          - numeric matrix of data
%         .output        - given idx for known values
%     figure             - comparison plot of silhouette and performance
%
% Other m-files required:
%     assignmentoptimal.m, Markus Buehren ...
%         http://www.mathworks.com/matlabcentral/fileexchange/ ...
%         6543-functions-for-the-rectangular-assignment-problem ...
%         /content/assignmentoptimal.m
%     This function implements the Hungarian Algorithm.
%
% Subfunctions:
%     significance       (C) Ahmad Alsahaf - GNU GPL
%     cluster_center     (C) Ahmad Alsahaf - GNU GPL
%     algo_dist          (C) Ahmad Alsahaf - GNU GPL
%     dist_to_center     (C) Ahmad Alsahaf - GNU GPL
%
%     These subfunctions can also be found as part of Ahmad Alsahaf's...
%       amjams/mixedkmeans package on MATLAB Central/FileExchange.  They ...
%       have been modified for use, and are inluded in kmeansCompare.m.
%       http:///www.mathworks.com/matlabcentral/fileexchange
%
% Author: Camden Glenn Bock
% 598 Bates College, Lewistion, ME 04240
% cbock@bates.edu, camdenbock@gmail.com
% http://www.camdenbock.com
% December 2015; Last Revision: 12/30/2015
%
%% Copyright (C) 2016  Camden Bock - GPL v. 3.0
%
% 'This program is liscensed under GPL v3.0'
% 'This program is modified from Ahmad Alsahaf`s package: ...
% amjams/mixedkmeans'.
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
%
% 'This program comes with ABSOLUTELY NO WARRANTY;' ...
% 'for details type view source. This is free software, and' ...
% 'you are welcome to redistribute it display under certain' ...
% 'conditions; see <http://www.gnu.org/licenses/>', ...
% ('Copyright (C) 2016  Camden Bock, Bates College'))



%------------- BEGIN CODE --------------

%% Initialize Variables

[dn, dm] = size(data);
[ni, ti] = size(inputType);
[no, to] = size(output);
if nargin < 7
    turnoffFigures = 0;
elseif nargin < 6
    trialsNo = 1;
elseif nargin < 5
    output = ones(1:dn);
    display('No Output Comparison.  Ignore Performance Results')
elseif nargin < 4
    inputType = [];
elseif nargin < 3
    max_iter = 1000;
elseif nargin < 2
    display('Not Enough Arguments')
end

m_distance = zeros(dn,k,trialsNo);
n_distance = zeros(dn,k,trialsNo);

if dn ~= no
    display('Bad Output Width')
    return
elseif to ~= ni
    display('input output mismatch')
    return
elseif dm ~= ti
    display('Bad input length')
    return
else
    waitlen = .05;
    prog = waitbar(waitlen,'Arguments are good');
    prog.Position = [200,200,280,50];
    prog.Name = 'Kmeans Comparison';
end

%% Mixed KMeans
performance_mixed = zeros(1,trialsNo);
silhouette_mixed_mean = zeros(1,trialsNo);

m_idx = zeros(dn,trialsNo);

tic
waitlen = waitlen + .05;
waitbar(waitlen,prog,'Mixed K-Means')

[n,m] = size(data);
idx_num = find(~inputType);

%% Normalize Numeric Data
waitbar(.1, prog, 'Normalize Numerical Features')

for i=1:numel(idx_num)
    data(:,idx_num(i)) = (data(:,idx_num(i)) - ...
        repmat(min(data(:,idx_num(i))),size(data(:,idx_num(i))))) ...
        /(max(data(:,idx_num(i)))-min(data(:,idx_num(i))));
end

waitbar(.15, prog, 'Find a discrete version of numerical attributes');
%% Discretize Numeric Data
data_discrete = data;
max_k = 50;
for i=1:numel(idx_num)
    silh_avg = zeros(max_k,1);
    data_num = data(:,idx_num(i));
    parfor k_iter=1:max_k
        [~,~,~,D]=kmeans(data_num,k_iter+1,'dist', ...
            'sqeuclidean','MaxIter',10000,'Options',statset('UseParallel',1));
        [Drow,~] = size(D);
        silh = zeros(1,Drow);
        for drow = 1:Drow
            [a_drow,excl_D] = min(D(drow,:));
            b_drow = min(D(drow,[1:(excl_D-1),(excl_D+1):end]));
            silh(drow) = (b_drow-a_drow)/max(a_drow,b_drow);
        end
        silh_avg(k_iter) = mean(silh);
    end
    [~,k_best] = max(silh_avg);
    k_best = k_best+1;
    data_discrete(:,idx_num(i)) = kmeans(data(:,idx_num(i)),k_best);
end

waitbar(.20, prog, 'Find All Significances')

%% Find signficance of each attribute
significances = zeros(m,1);
for i=1:m
    significances(i) = significance(data_discrete,i);
end

%% Mixed K-means Clustering Assignments
iMixed = 1;
while iMixed < trialsNo+1
    try
        curr_idx = randi([1 k],n,1);
        
        all_dist = algo_distance(data_discrete);
        
        new_idx = zeros(n,1);
        
        count = 0;
        while(isequal(new_idx,curr_idx)==0 && count<max_iter)
            
            if count>0
                curr_idx = new_idx;
            end
            
            all_centers = struct;
            for i=1:k
                curr_cluster = data(curr_idx==i,:);
                curr_center = cluster_center(curr_cluster,inputType);
                name = ['center_',sprintf('%03d',i)];
                all_centers.(name) = curr_center;
            end
            
            silh_c = zeros(1,n);
            for i=1:n
                k_distances = zeros(k,1);
                data_i = data(i,:);
                parfor j=1:k
                    name_now = ['center_',sprintf('%03d',j)];
                    center_now = all_centers.(name_now);
                    k_distances(j) = dist_to_center(data_i,center_now, ...
                        inputType,significances,all_dist);
                end
                
                [~,new_idx(i)] = min(k_distances);
                m_distance(i,:,iMixed) = k_distances;
                min1 = min(k_distances);
                min2 = min(setdiff(k_distances(:),min(k_distances(:))));
                silh_c(i) = (min2-min1)/max(min1,min2);
            end
            count = count+1;
        end
        
        idx = new_idx;
        m_idx(:,iMixed) = idx;
        silhouette_mixed_mean(iMixed) = mean(silh_c);       
        %%  Mixed KMeans Error Analysis
        ErrorMatrix = zeros(k);
        output_values = unique(output);
        for emCol = 1:k
            parfor emRow = 1:k
                output_emRow = output_values(emRow);
                for oRow = 1:length(output)
                    if (output(oRow) ~= output_emRow) && ...
                            (idx(oRow) == emCol);
                        ErrorMatrix(emCol,emRow) ...
                            = ErrorMatrix(emCol,emRow)+1;
                    end
                end
            end
        end
        [mEM, nEM] = size(ErrorMatrix);
        if mEM~=nEM
            display('Warning, matrix must be square');
        end
        [~, count] = assignmentoptimal(ErrorMatrix);
        performance_mixed(iMixed) = 1-count/length(idx);
        waitlen = waitlen + (.9-waitlen)/20;
        waitbar(waitlen,prog,'Mixed Kmeans')
    catch
       fprintf('Error Non-existent field categorical. iMixed = %d', ...
           iMixed);
       display('- - - -  execution will continue  - - - -')
       iMixed = iMixed-1;
    end
    iMixed = iMixed+1;
end


performance_mixed_mean = mean(performance_mixed);

%% Numeric Kmenas
performance_normal = zeros(1,trialsNo);
silhouette_normal_mean = zeros(1,trialsNo);
n_idx = zeros(dn,trialsNo);
waitlen = .1;
waitbar(waitlen,prog,'normal Kmeans')
for iNormal=1:trialsNo
    [idx,~,~,NK_Distances] = kmeans(data, k,'Options',statset('UseParallel',1));
    n_idx(:,iNormal) = idx;
    %% Numeric KMeans Error Analysis
    [nDrow,~] = size(NK_Distances);
    n_distance(:,:,iNormal) = NK_Distances;
    nSilh = zeros(1,nDrow);
    for drow = 1:nDrow
        [a_drow,excl_D] = min(NK_Distances(drow,:));
        b_drow = min(NK_Distances(drow,[1:(excl_D-1),(excl_D+1):end]));
        nSilh(drow) = (b_drow-a_drow)/max(a_drow,b_drow);
    end
    silhouette_normal_mean(iNormal) = mean(nSilh);
    
    ErrorMatrix = zeros(k);
    output_values = unique(output);
    for emCol = 1:k
        parfor emRow = 1:k
            output_emRow = output_values(emRow);
            for oRow = 1:length(output)
                if (output(oRow) ~= output_emRow) && (idx(oRow) == emCol);
                    ErrorMatrix(emCol,emRow) = ErrorMatrix(emCol,emRow)+1;
                end
            end
        end
    end
    
    [mEM, nEM] = size(ErrorMatrix);
    if mEM~=nEM
        display('Warning, matrix must be square');
    end
    [~, count] = assignmentoptimal(ErrorMatrix);
    performance_normal(iNormal) = 1-count/length(idx);
    
    waitlen = waitlen + (.9 - trialsNo)/20;
    waitbar(waitlen,prog,'normal Kmeans')
end

performance_normal_mean = mean(performance_normal);
toc

%% Reporting Error Analysis

perfCompare = [performance_mixed; performance_normal];
silhCompare = [silhouette_mixed_mean; silhouette_normal_mean];

stat = {'Performance';'Silhouette'};
Mixed_kMeans = [mean(perfCompare(1,:)); mean(silhCompare(1,:))];
Numeric_kMeans = [mean(perfCompare(2,:)); mean(silhCompare(2,:))];
StatsTable = table(Mixed_kMeans,Numeric_kMeans,'RowNames',stat);

display('-------------------------')

disp(StatsTable)

display('-------------------------')

waitbar(.95,prog,'Performance Plots')

if (trialsNo < 75)&&(turnoffFigures == 0)
    figure
    subplot(2,1,1)
    bar(perfCompare)
    title('Mixed (L) vs. Numeric (R): Performance in clusters given output')
    xlabel('Trial Number')
    ylabel('Performance Ratio')
    subplot(2,1,2)
    bar(silhCompare)
    title('Mixed (L) vs. Numeric (R): Average Silhouette Value')
    xlabel('Trial Number')
    ylabel('Silhouette Value')
end

close(prog)

% Output Variables
%Output Variables

mixedClustering = struct;
    mixedClustering.k = k;
    mixedClustering.idx = m_idx;
    mixedClustering.silhouette = silhCompare(1,:);
    mixedClustering.performance = perfCompare(1,:);
    mixedClustering.distance = m_distance;
    mixedClustering.trialsNo = trialsNo;
    
numericClustering = struct;
    numericClustering.k = k;
    numericClustering.idx = n_idx;
    numericClustering.silhouette = silhCompare(2,:);
    numericClustering.performance = perfCompare(2,:);
    numericClustering.distance = n_distance;
    numericClustering.trialsNo = trialsNo;
    
origionalData = struct;
    origionalData.data = data;
    origionalData.output = output;
end

%---------------------------------------------------------------
%% Significances
function sig = significance(D,idx)
%SIGNIFICANCE: finds the significance of a categorical attribute or a
%discretized version of a numerical attribute

% input:
%   D:   the dataset of all attributes
%   idx: index of the attribute whose significance is to be found
%
% ouput:
%   sig: the significance of the attribute
%
%
% Copyright 2015 Ahmad Alsahaf
% Research fellow, Politecnico di Milano
% ahmadalsahaf@gmail.com

% number of attributes
m = size(D,2);

% define the attribute, its unique values, and all unique pairs
a = D(:,idx);
unique_a = find(accumarray(a+1,1))-1;
all_pairs = nchoosek(unique_a,2);
num_pairs = size(all_pairs,1);

% the number of all delta distances
num_delta = (m-1)*num_pairs;

% find all deltas and average them
feature_c = 1:m;  feature_c(idx)=[];   %complementary feature set
delta_sum = 0;                         %initialize
for i=1:num_pairs
    curr_pair = all_pairs(i,:);
    for j=1:(m-1)
        % intialize distance
        d = 0;
        
        % initalize support set
        w = [];
        w_c = [];
        
        % the number of categorical values in D(:,feature_c(j))
        unique_j = find(accumarray(D(:,feature_c(j))+1,1))-1;
        vj = numel(unique_j);
        
        
        % begin algorithm
        for t = 1:vj
            ut = unique_j(t);
            
            % locations
            ut_in_aj = find(D(:,feature_c(j))==ut);
            x_in_ai = find(a==curr_pair(1));
            y_in_ai = find(a==curr_pair(2));
            
            % probabilities
            p_ux = numel(x_in_ai(ismembc(x_in_ai,ut_in_aj))) ...
                /numel(x_in_ai);
            p_uy = numel(y_in_ai(ismembc(y_in_ai,ut_in_aj))) ...
                /numel(y_in_ai);
            
            % conditions
            if p_ux>= p_uy
                w = [w;ut];          %update support set
                d = d+p_ux;          %update distance
            else
                w_c = [w_c;p_uy];    %update complement support set
                d = d+p_uy;          %update distance
            end
            
            
        end
        delta = d-1;                      %restrict distance to [0,1]
        delta_sum = delta_sum + delta;
    end
end
% find average distance, which is the significance
sig = delta_sum/num_delta;
end


%% Algo Distance

function all_dist = algo_distance(data_discrete)
% Copyright 2015 Ahmad Alsahaf
% Research fellow, Politecnico di Milano
% ahmadalsahaf@gmail.com

% data dimenionsality
[~,m] = size(data_discrete);

%intialize distance vector; which contains all distances between all pairs
all_dist = [];

for i = 1:m
    % define ai, the current attribute
    ai = data_discrete(:,i);
    
    % find all pairs of unique values in current feature
    unique_ai = find(accumarray(ai+1,1))-1;
    all_pairs = nchoosek(unique_ai,2);
    
    % find complement feature set
    feat_c = 1:m;  feat_c(i) = [];
    
    for j= 1:size(all_pairs,1)
        % initialize sum and define current pair
        sum_delta = 0;
        curr_pair = all_pairs(j,:);
        
        % find distance between the pair for all Aj
        for k = 1:m-1
            % define aj
            aj = data_discrete(:,feat_c(k));
            
            % update the sum
            % intialize distance
            d = 0;
            
            % initalize support set
            w = [];
            w_c = [];
            
            % the number of categorical values in aj
            unique_j = find(accumarray(aj+1,1))-1;
            
            vj = numel(unique_j);
            
            % begin algorithm
            for t = 1:vj
                ut = unique_j(t);
                
                % locations
                ut_in_aj = find(aj==ut);
                x_in_ai = find(ai==curr_pair(1));
                y_in_ai = find(ai==curr_pair(2));
                
                % probabilities
                p_ux = numel(x_in_ai(ismembc(x_in_ai,ut_in_aj))) ...
                    /numel(x_in_ai);
                p_uy = numel(y_in_ai(ismembc(y_in_ai,ut_in_aj))) ...
                    /numel(y_in_ai);
                
                % conditions
                if p_ux>= p_uy
                    w = [w;ut];          %update support set
                    d = d+p_ux;          %update distance
                else
                    w_c = [w_c;p_uy];    %update complement support set
                    d = d+p_uy;          %update distance
                end
                
                
            end
            delta = d-1;                      %restrict distance to [0,1]
            sum_delta = sum_delta + delta;
        end
        %         update the distance vector
        sum_delta = sum_delta/(m-1);
        
        %         arranged as [attribute_idx,first_value(lower), ...
        %         second_value(higher),distance];
        pair_sorted = sort(curr_pair,'ascend');
        all_dist = [all_dist; ...
            i,pair_sorted(1),pair_sorted(2),sum_delta];
    end
end
end
%% Cluster Center
function [ center ] = cluster_center( cluster, input_type )
%CLUSTER_CENTER find cluster centers for mixed attributes

% inputs:
%     cluster:    the members of the cluster
%     input_type: binary index indicating the type of attributes...
%     (1 for categorical)
%
% output:
%     center:     the center of the cluster
% Copyright 2015 Ahmad Alsahaf
% Research fellow, Politecnico di Milano
% ahmadalsahaf@gmail.com

% intialize a structure variable to save the centers

center = struct;

% cluster dimensions, and numerical and categorical feature indices
[n,~] = size(cluster);
center.cluster_size = n;
cat_idx = find(input_type);
num_idx = find(~input_type);


% find center for each numerical attribute
for i=1:numel(num_idx)
    curr_att = cluster(:,num_idx(i));
    name = ['att_',sprintf('%03d',num_idx(i))];
    center.numerical.(name) = mean(curr_att);
end

% find center for each categorical attribute
for i=1:numel(cat_idx)
    curr_att = cluster(:,cat_idx(i));
    name = ['att_',sprintf('%03d',cat_idx(i))];
    uniq_curr_att = find(accumarray(curr_att+1,1))-1;
    
    for j=1:numel(uniq_curr_att)
        name_value = ['value_',sprintf('%03d',j)];
        curr_value = uniq_curr_att(j);
        count_value = numel(find(curr_att==curr_value));
        center.categorical.(name).(name_value).value = curr_value;
        center.categorical.(name).(name_value).count = count_value;
    end
end

end

%% Distance to Center

function theta = dist_to_center(x,c,input_type,sig,dist_all)

% dist_to_center: computes the the distance between a data point and a
% cluster center

% inputs:
%     x:              a data point
%     c:              a cluster center (structure)
%     input_type:     binary index indicating attributes (1 = categorical)
%     sig:            significance of all attributes in the dataset
%     dist_all:       list of all distances of categorical values
%
% output:
%     theta:  the distance between x and c
%
%
% Copyright 2015 Ahmad Alsahaf
% Research fellow, Politecnico di Milano
% ahmadalsahaf@gmail.com

% find indices
cat_idx = find(input_type);
num_idx = find(~input_type);

% load cluster size
cluster_size = c.cluster_size;

% distance for numerical attributes

% initialize numerical distance to zero
sum_distance_numerical = 0;

% find distance for each numerical attribute and add to sum
for i=1:numel(num_idx)
    d = x(num_idx(i));
    name = ['att_',sprintf('%03d',num_idx(i))];
    num_center = c.numerical.(name);
    curr_significance = sig(num_idx(i));
    curr_dist = (curr_significance*(d-num_center))^2;
    sum_distance_numerical = sum_distance_numerical+curr_dist;
end

% display(c)
% initialize categorical distance to zero
sum_distance_categorical = 0;

% find distance for each categorical attribute and add to sum

for i=1:numel(cat_idx)
    % access the current categorical attribute from structure
    name = ['att_',sprintf('%03d',cat_idx(i))];
    curr_att = c.categorical.(name);
    
    
    % initialize sum for this categorical attribute
    sum_categorical_current = 0;
    
    % now access values within that attribute in the cluster
    value_names = fieldnames(curr_att);
    
    for j=1:numel(value_names)
        value_in_point = x(cat_idx(i));
        value_in_cluster = curr_att.(value_names{j}).value;
        count_in_cluster = curr_att.(value_names{j}).count;
        
        % find the distance from the list
        sorted_values = sort([value_in_point,value_in_cluster],'ascend');
        idx_dist = dist_all(:,1)==cat_idx(i)&dist_all(:,2) == ...
            sorted_values(1) & dist_all(:,3) == sorted_values(2);
        
        % set distance to zero if value is equal to center, compute dist
        % othewise (i.e. only update when different values
        
        if (sorted_values(1) ~= sorted_values(2))
            sum_categorical_current = sum_categorical_current ...
                + (1/cluster_size)*count_in_cluster*dist_all(idx_dist,4);
        end
    end
    sum_distance_categorical = sum_distance_categorical ...
        +(sum_categorical_current)^2;
end

% overall distance
theta = sum_distance_numerical + sum_distance_categorical;
end

