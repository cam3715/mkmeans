classdef clusteringCompare
%CLUSTERINGCOMPARE Summary of this class goes here
%   Detailed explanation goes here
%    
% Author: Camden Glenn Bock
% 598 Bates College, Lewistion, ME 04240
% cbock@bates.edu, camdenbock@gmail.com
% http://www.camdenbock.com
% December 2015; Last Revision: 12/30/2015
%
%% Copyright (C) 2016  Camden Bock - GPL v. 3.0
%
% 'This program is liscensed under GPL v3.0'
% 'This program is modified from Ahmad Alsahaf`s package: ...
% amjams/mixedkmeans'.
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
%
% 'This program comes with ABSOLUTELY NO WARRANTY;' ...
% 'for details type view source. This is free software, and' ...
% 'you are welcome to redistribute it display under certain' ...
% 'conditions; see <http://www.gnu.org/licenses/>', ...
% ('Copyright (C) 2016  Camden Bock, Bates College'))



%% ------------- BEGIN CODE --------------
    
    properties
        mixedClust
        numericClust
        originalData
    end
    methods
        function obj = clusteringCompare(filename, catAttributes, ncols, ...
                startRow, trialsNo)
            result = kmeansCompare_fs(filename, catAttributes, ncols, ...
                startRow, trialsNo, 1);
            obj.mixedClust = result.mixedClustering;
            obj.numericClust = result.mixedClustering;
            obj.originalData = result.origionalData;
        end
        function visulaizeNum(obj, trialnum)
            if nargin < 2
                trialnum = 1;
            end
            pointClusterVis(obj.numericClust, trialnum)
        end
        function visualizeMix(obj, trialnum)
            if nargin < 2
                trialnum = 1;
            end
            pointClusterVis(obj.mixedClust, trialnum)
        end
    end
    
end